// Set this to true only after the APK has been rebuilt without embedded provider secrets.
const APP_DOWNLOAD_ENABLED = false;
// Upload the security-reviewed APK to downloads/app.apk, then keep this relative URL.
const APP_DOWNLOAD_URL = "downloads/app.apk";
const menuBtn=document.getElementById("menuBtn");
const nav=document.getElementById("nav");
menuBtn?.addEventListener("click",()=>nav.classList.toggle("open"));
document.getElementById("year").textContent=new Date().getFullYear();
const downloadBtn=document.getElementById("downloadBtn");
const status=document.getElementById("downloadStatus");
if(APP_DOWNLOAD_ENABLED){
  downloadBtn.href=APP_DOWNLOAD_URL;
  downloadBtn.download="Sarswati-Puja-Samiti-Baghakol.apk";
  downloadBtn.classList.remove("disabled");
  downloadBtn.removeAttribute("aria-disabled");
  downloadBtn.textContent="Download Android APK ↓";
  status.textContent="Official Android application. Verify the publisher before installing.";
}
const qrBox=document.getElementById("qrcode");
const qrUrl=window.location.href.split("#")[0]+"#download";
if(window.QRCode){
  new QRCode(qrBox,{text:qrUrl,width:210,height:210,colorDark:"#182044",colorLight:"#ffffff",correctLevel:QRCode.CorrectLevel.H});
  const save=document.getElementById("saveQr");
  save.disabled=false;
  save.addEventListener("click",()=>{
    const canvas=qrBox.querySelector("canvas");
    const img=qrBox.querySelector("img");
    const data=canvas?canvas.toDataURL("image/png"):img?.src;
    if(!data)return;
    const a=document.createElement("a");a.href=data;a.download="Sarswati-Puja-Samiti-Website-QR.png";a.click();
  });
}else{
  qrBox.textContent="QR library could not load. Check internet connection.";
}
